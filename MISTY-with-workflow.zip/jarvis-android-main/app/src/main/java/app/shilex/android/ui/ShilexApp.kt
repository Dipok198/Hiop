package app.shilex.android.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.shilex.android.assistant.AssistantViewModel
import app.shilex.android.assistant.UiState
import app.shilex.android.local.ActivityLog
import app.shilex.android.local.LocalPhase
import app.shilex.android.task.Task

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Filled.Home),
    Chat("Chat", Icons.Filled.ChatBubbleOutline),
    Memory("Memory", Icons.Filled.Psychology),
    Privacy("Privacy", Icons.Filled.VerifiedUser),
    Tools("Tools", Icons.Filled.BarChart),
}

@Composable
fun ShilexApp(assistant: AssistantViewModel) {
    val state by assistant.state.collectAsStateWithLifecycle()
    val localPhase by assistant.localPhase.collectAsStateWithLifecycle()
    val activity by assistant.activity.collectAsStateWithLifecycle()
    val wakeWord by assistant.wakeWord.collectAsStateWithLifecycle()
    val level by assistant.level.collectAsStateWithLifecycle()
    val task by assistant.task.collectAsStateWithLifecycle()
    var onboarded by rememberSaveable { mutableStateOf(assistant.onboarded) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showSettings by rememberSaveable { mutableStateOf(false) }

    ShilexTheme {
        Surface(color = MaterialTheme.colorScheme.background, contentColor = MaterialTheme.colorScheme.onBackground) {
            Box(Modifier.fillMaxSize()) {
                HudBackground(Modifier.fillMaxSize())
                Content(
                    assistant = assistant,
                    state = state,
                    localPhase = localPhase,
                    level = level,
                    task = task,
                    activity = activity,
                    wakeWord = wakeWord,
                    onboarded = onboarded,
                    onOnboarded = { onboarded = true },
                    tab = tab,
                    setTab = {
                        showSettings = false
                        tab = it
                    },
                    showSettings = showSettings,
                    setShowSettings = { showSettings = it },
                )
            }
        }
    }
}

@Composable
private fun Content(
    assistant: AssistantViewModel,
    state: UiState,
    localPhase: LocalPhase,
    level: Float,
    task: Task?,
    activity: List<ActivityLog.Entry>,
    wakeWord: Boolean,
    onboarded: Boolean,
    onOnboarded: () -> Unit,
    tab: Int,
    setTab: (Int) -> Unit,
    showSettings: Boolean,
    setShowSettings: (Boolean) -> Unit,
) {
    if (!onboarded || !state.hasKey) {
        Box(Modifier.fillMaxSize().safeDrawingPadding()) {
            Onboarding(assistant, state.hasKey) {
                assistant.onboarded = true
                onOnboarded()
            }
        }
        return
    }
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            Column {
                // Subtle glowing neon horizon line above bottom navigation bar
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(1.5.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, MistyNeonPurple, MistyMagentaGlow, MistyNeonPurple, Color.Transparent)
                            )
                        )
                )
                NavigationBar(
                    containerColor = Color(0xF20B0618),
                    tonalElevation = 0.dp,
                ) {
                    Tab.entries.forEach {
                        NavigationBarItem(
                            selected = !showSettings && tab == it.ordinal,
                            onClick = { setTab(it.ordinal) },
                            icon = { Icon(it.icon, contentDescription = it.label) },
                            label = { Text(it.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MistyElectricViolet,
                                selectedTextColor = MistyElectricViolet,
                                indicatorColor = MistyNeonPurple.copy(alpha = 0.25f),
                                unselectedIconColor = MistyTextSecondary,
                                unselectedTextColor = MistyTextSecondary,
                            ),
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (showSettings) {
                SettingsScreen(assistant)
            } else {
                when (Tab.entries[tab]) {
                    Tab.Home -> HomeScreen(
                        state = state,
                        localPhase = localPhase,
                        level = level,
                        task = task,
                        activity = activity,
                        wakeOn = assistant.wakeWordAvailable && wakeWord,
                        onStart = assistant::start,
                        onStartWithText = assistant::startWithText,
                        onStop = assistant::stop,
                        onInterrupt = assistant::interrupt,
                        onMicDenied = assistant::micUnavailable,
                        onPermissionAnswered = assistant::permissionAnswered,
                        onQuick = assistant::quick,
                        onSeeActivity = { setTab(Tab.Memory.ordinal) },
                        onOpenSettings = { setShowSettings(true) },
                        onOpenTools = { setTab(Tab.Tools.ordinal) },
                        favourites = remember(activity.size) { assistant.favourites() },
                    )
                    Tab.Chat -> ChatScreen(
                        lines = state.lines,
                        onSendMessage = assistant::startWithText,
                    )
                    Tab.Memory -> ActivityScreen(activity, assistant::clearActivity)
                    Tab.Privacy -> PrivacyScreen(assistant)
                    Tab.Tools -> AutomationsScreen()
                }
            }
        }
    }
}
