package app.shilex.android.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.shilex.android.Branding
import app.shilex.android.assistant.AssistantViewModel
import app.shilex.android.memory.MemoryStore
import app.shilex.android.wake.WakeWordModel

@Composable
fun PrivacyScreen(assistant: AssistantViewModel) {
    val context = LocalContext.current
    val wakeOn by assistant.wakeWord.collectAsStateWithLifecycle()
    val memory = remember { MemoryStore(context) }
    var notesCount by remember { mutableStateOf(memory.notes().size) }
    var learned by remember { mutableStateOf(assistant.learnedSummary()) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        notesCount = memory.notes().size
        learned = assistant.learnedSummary()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Text("Privacy & Voice Lock", style = MaterialTheme.typography.headlineSmall, color = MistyElectricViolet)

        Section("Speaker Verification & Wake Word") {
            if (assistant.wakeWordAvailable) {
                SwitchRow(
                    "Wake word "${WakeWordModel.PHRASE}"",
                    "Processed locally on your phone only. Nothing leaves your device until triggered.",
                    wakeOn,
                ) { assistant.setWakeWord(it) }
                VoiceSetupRow(
                    saved = assistant.voiceSaved,
                    record = assistant::recordVoiceSample,
                    onSave = assistant::saveVoice,
                    onForget = assistant::forgetVoice,
                )
            } else {
                InfoRow("On-Device Wake Engine", "Tap the mic on Home to talk hands-free.")
            }
        }

        Section("Personal Memory Vault") {
            InfoRow(
                "Saved Notes",
                "$notesCount private note(s) stored encrypted locally on this phone.",
            ) {
                if (notesCount > 0) {
                    TextButton(onClick = {
                        memory.clearNotes()
                        notesCount = 0
                    }) { Text("Clear All") }
                }
            }
            InfoRow("Learned Habits", learned) {
                TextButton(onClick = {
                    assistant.forgetLearned()
                    learned = assistant.learnedSummary()
                }) { Text("Forget") }
            }
        }

        Section("Device Security & Permissions") {
            ControlCard(Modifier.padding(vertical = 6.dp), showWhenOn = true)
            InfoRow(
                "Zero Audio Storage",
                "${Branding.ASSISTANT_NAME} never records or stores your voice files. API keys are hardware-backed via Android Keystore.",
            ) {
                TextButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = android.net.Uri.parse("package:${context.packageName}")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                }) { Text("App Info") }
            }
        }

        Spacer(Modifier.height(12.dp))
    }
}
